﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditorInternal;
using System.Linq;

public class IntersectionManager : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The IntersectionManager script is responsible to let the vehicle know to which positions it has to drive in an Intersection
    //It takes the information given by the vehicle (On what street is the vehicle?) and returns at what position 
    //the current part-destination (end of street / exit on intersection) is and how to get there
    //It is located on the intersections

    #endregion

    #region Variables

    private RaycastHit hit;

    public List<Transform> crossSensors;
    public List<Transform> entrances;
    public List<Transform> exits;
    public List<Transform> streets;
    public List<Transform> streetLanes;

    #endregion

    public void InitializeIntersectionManager()
    {
        crossSensors = new Transform[5].ToList();
        entrances = new Transform[4].ToList();
        exits = new Transform[4].ToList();
        streets = new Transform[4].ToList();
    }

    public void DetectConnectingStreets()
    {
        if (Physics.Raycast(transform.position, transform.forward, out hit, 6))
            streets[1] = hit.transform;
        if (Physics.Raycast(transform.position, -transform.forward, out hit, 6))
            streets[3] = hit.transform;
        if (Physics.Raycast(transform.position, transform.right, out hit, 6))
            streets[2] = hit.transform;
        if (Physics.Raycast(transform.position, -transform.right, out hit, 6))
            streets[0] = hit.transform;

        foreach (Transform street in streets)
        {
            if (street != null)
            {
                streetLanes.Add(street.GetChild(0).transform);
                streetLanes.Add(street.GetChild(1).transform);
                Destroy(street.GetComponent<Rigidbody>());
            }
            else
            {
                streetLanes.Add(null);
                streetLanes.Add(null);
            }
        }
    }

    public void DetectSensors()
    {
        Collider[] collisionCollider = Physics.OverlapSphere(position: transform.position, radius: 7f);

        foreach (Collider collision in collisionCollider)
        {
            Transform transform = collision.transform;

            if (collision.tag == "Entrance")
            {
                //Name Format : "Entrance_1" -> Nr = pos -> 9
                //Gets the Number of the Name
                int Nr = int.Parse(transform.name[9].ToString());
                entrances[Nr - 1] = transform;
                transform.GetComponent<Collider>().enabled = false;
                Destroy(transform.GetComponent<Rigidbody>());
            }
            if (transform.tag == "Exit")
            {
                //Name Format : "Exit_1" -> Nr = pos -> 5
                //Gets the Number of the Name
                int Nr = int.Parse(transform.name[5].ToString());
                exits[Nr - 1] = transform;
                transform.GetComponent<Collider>().enabled = false;
                Destroy(transform.GetComponent<Rigidbody>());
            }
            if (transform.tag == "CrossSensor")
            {
                //Name Format : "CrossSensor_1" -> Nr = pos -> 12
                //Gets the Number of the Name
                int Nr = int.Parse(transform.name[12].ToString());
                crossSensors[Nr - 1] = transform;
                transform.GetComponent<Collider>().enabled = false;
                Destroy(transform.GetComponent<Rigidbody>());
            }
        }
    }

    public void SetVehicleEntranceAndExit(Transform Vehicle)
    {
        IntersectionVehicleInformation vehicleIVI = Vehicle.GetComponent<VehicleManager>().intersectionVehicleInformation;

        vehicleIVI.vehicleEntrance = GetEntranceNumber(Vehicle);

        int entranceNumber = GetEntranceNumber(Vehicle);
        Transform vehicleExit = GetExit(Vehicle, entranceNumber);

        for (int i = 0; i < exits.Count; i++)
        {
            if(exits[i] == vehicleExit)
            {
                vehicleIVI.vehicleExit = i;
            }
        }
    }

    public void DriveToEntrance(Transform vehicle)
    {
        VehicleMover vehicleMover = vehicle.GetComponent<VehicleMover>();
        VehicleManager vehicleManager = vehicle.GetComponent<VehicleManager>();

        Transform MyEntrance = null;
        for (int i = 0; i < streetLanes.Count; i++)
        {
            if (streetLanes[i] == vehicleManager.currentStreet)
            {
                int entranceNumber = Mathf.RoundToInt(i / 2);
                MyEntrance = entrances[entranceNumber];
            }
        }

        if (vehicleManager.currentStreet.parent.GetComponent<StreetManagement>().isCurve == true)
        {
            Transform myPath = vehicleManager.currentStreet.GetChild(0);
            Vector3 vertexPoint = new Vector3(myPath.GetChild(1).position.x, myPath.GetChild(1).position.y + vehicle.localScale.y / 2, myPath.GetChild(1).position.z);
            Vector3 endPoint = new Vector3(myPath.GetChild(2).position.x, myPath.GetChild(2).position.y + vehicle.localScale.y / 2, myPath.GetChild(2).position.z);

            vehicleMover.SetPosition(pos_StartPoint: vehicle.position, pos_VertexPoint: vertexPoint, pos_EndPoint: endPoint, drivingToEntrance: true);
        }
        else
        {
            Vector3 endPoint = new Vector3(MyEntrance.position.x, transform.position.y + 0.5f + vehicle.localScale.y / 2, MyEntrance.position.z);
            vehicleMover.SetPosition(pos_StartPoint: vehicle.position, pos_VertexPoint: vehicle.position, pos_EndPoint: endPoint, drivingToEntrance: true);
        }
    }

    public int GetEntranceNumber(Transform vehicle)
    {
        int entranceNumber = 0;
        VehicleManager vehicleManager = vehicle.GetComponent<VehicleManager>();

        for (int i = 0; i < streetLanes.Count; i++)
        {

            if (streetLanes[i] == vehicleManager.currentStreet)
            {
                entranceNumber = i / 2;
            }
        }

        return entranceNumber;
    }

    public Transform GetEntrance(int entranceNumber)
    {
        return entrances[entranceNumber];
    }

    public Transform GetExit(Transform vehicle, int entranceNumber)
    {
        Transform exit = null;
        VehicleMover vehicleMover = vehicle.GetComponent<VehicleMover>();
        char direction = vehicleMover.directions[vehicleMover.turnsDone];

        if (direction == 's')
        {
            exit = exits[entranceNumber];
        }
        else if (direction == 'l')
        {
            if (entranceNumber - 1 >= 0)
            {
                exit = exits[entranceNumber - 1];
            }
            else
            {
                exit = exits[exits.Count - 1];
            }
        }
        else if (direction == 'r')
        {
            if (entranceNumber + 1 < exits.Count)
            {
                exit = exits[entranceNumber + 1];
            }
            else
            {
                exit = exits[0];
            }
        }

        return exit;
    }

    public Vector3 GetCrossSensor(Transform vehicle, Vector3 pos_Entrance, Vector3 pos_Exit, int entranceNumber)
    {
        VehicleMover vehicleMover = vehicle.GetComponent<VehicleMover>();
        char direction = vehicleMover.directions[vehicleMover.turnsDone];

        Vector3 pos_CrossSensor = Vector3.zero;

        if(direction == 's')
        {
            pos_CrossSensor = crossSensors[entranceNumber].position;
        }
        if(direction == 'l')
        {
            pos_CrossSensor = crossSensors[crossSensors.Count - 1].position;
        }
        if(direction == 'r')
        {
            if (pos_Entrance.x > pos_Exit.x && pos_Exit.x > 0)
            {
                //Entrance.x = 5.0
                //Exit.x = 2.5
                pos_CrossSensor = new Vector3(2.75f, 0, 2.75f) + transform.position;
            }
            else if (pos_Entrance.x > pos_Exit.x && pos_Exit.x < 0)
            {
                //Entrance.x = -2.5
                //Exit.x = -5.0
                pos_CrossSensor = new Vector3(-2.75f, 0, 2.75f) + transform.position;
            }
            else if (pos_Entrance.x < pos_Exit.x && pos_Exit.x < 0)
            {
                //Entrance.x = -5.0
                //Exit.x = -2.5
                pos_CrossSensor = new Vector3(-2.75f, 0, -2.75f) + transform.position;
            }
            else if (pos_Entrance.x < pos_Exit.x && pos_Exit.x > 0)
            {
                //Entrance.x = 2.5
                //Exit.x = 5.0
                pos_CrossSensor = new Vector3(2.75f, 0, -2.75f) + transform.position;
            }
        }


        return pos_CrossSensor;
    }

    public void DriveTroughIntersection(Transform vehicle)
    {
        VehicleMover vehicleMover = vehicle.GetComponent<VehicleMover>();

        int entranceNumber = GetEntranceNumber(vehicle: vehicle);
        Transform entrance = GetEntrance(entranceNumber: entranceNumber);
        Transform exit = GetExit(vehicle: vehicle, entranceNumber: entranceNumber);
        Vector3 pos_Exit = exit.position;
        Vector3 pos_CrossSensor = GetCrossSensor(vehicle: vehicle, pos_Entrance: entrance.localPosition, pos_Exit: exit.localPosition, entranceNumber: entranceNumber);

        Vector3 startPoint = new Vector3(vehicle.position.x, vehicle.position.y, vehicle.position.z);
        Vector3 vertexPoint = new Vector3(pos_CrossSensor.x, transform.position.y + 0.5f + vehicle.localScale.y / 2, pos_CrossSensor.z);
        Vector3 endPoint = new Vector3(pos_Exit.x, transform.position.y + 0.5f + vehicle.localScale.y / 2, pos_Exit.z);

        vehicleMover.SetPosition(pos_StartPoint: startPoint, pos_VertexPoint: vertexPoint, pos_EndPoint: endPoint, drivingToEntrance: false);

    }
}
