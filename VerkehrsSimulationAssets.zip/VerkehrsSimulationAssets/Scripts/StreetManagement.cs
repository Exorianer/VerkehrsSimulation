﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StreetManagement : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The StreetManagement script is a key component in the infrastructure
    //It makes the connection between street lanes and intersections possible
    //It is located on each street

    #endregion

    #region Variables

    public float streetLenght;

    public bool isCurve = false;
    public bool blocked = false;

    public List<Transform> intersection;
    public List<Transform> streetLanes = new List<Transform>();

    #endregion

    //This function is called to check and save the lenght of the Street.
    public void CalculateStreetLenght()
    {
        if(isCurve == false)
        {
            if (transform.localScale.x > transform.localScale.z)
                streetLenght = transform.localScale.x;
            else
                streetLenght = transform.localScale.z;
        }
        else
        {
            StreetDistance SD = GetComponent<StreetDistance>();
            SD.CreateCurveParabola();
            float accurateDistance = 0;
            float neededTime = SD.GetDuration();
            float timeFraction = neededTime / 100;
            Vector3 prevPoint = SD.GetPositionAtTime(0);
            List<float> distances = new List<float>();

            for (int i = 1; i <= 100; i++)
            {
                Vector3 cPoint = SD.GetPositionAtTime(timeFraction * i);

                distances.Add(Vector3.Distance(prevPoint, cPoint));

                prevPoint = cPoint;
            }

            for (int i = 0; i < distances.Count; i++)
            {
                accurateDistance += Mathf.Abs(distances[i]);
            }

            accurateDistance /= 5; //A street unity is normaly 5m long, but we work with if like it was 1m

            streetLenght = accurateDistance;
        }
    }

    public void DetectConnections()
    {
        SearchForStreetLanes();
        GetIntersectionsFromStreetLane();
    }

    private void SearchForStreetLanes()
    {
        RaycastHit hit;

        if(Physics.Raycast(origin: transform.position, direction: transform.forward, hitInfo: out hit, maxDistance: 2f))
        {
            streetLanes[0] = hit.transform;
        }

        if (Physics.Raycast(origin: transform.position, direction: -transform.forward, hitInfo: out hit, maxDistance: 2f))
        {
            streetLanes[1] = hit.transform;
        }
    }

    private void GetIntersectionsFromStreetLane()
    {
        if(streetLanes[0].GetComponent<StreetLaneManagement>().intersectionAtEntrance != null)
            intersection.Add(item: streetLanes[0].GetComponent<StreetLaneManagement>().intersectionAtEntrance);

        if (streetLanes[0].GetComponent<StreetLaneManagement>().intersectionAtExit != null)
            intersection.Add(item: streetLanes[0].GetComponent<StreetLaneManagement>().intersectionAtExit);
    }
}
