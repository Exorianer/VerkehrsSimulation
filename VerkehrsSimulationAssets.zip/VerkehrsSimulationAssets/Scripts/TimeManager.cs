﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeManager : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The TimeManager script is essential for this simulation
    //It creates "Ticks" for each vehicle approaching the intersection
    //A Tick has the information when a vehicle will be at the intersection
    //And lets the vehicle calculate how it has to drive to arrive at that destination time
    //It is located on the intersection

    #endregion

    #region Variables

    private TrafficManager trafficManager;

    [SerializeField] private List<Transform> vehiclesWithoutTick = new List<Transform>();
    [SerializeField] private List<Transform> potentialVehiclesWithoutTick = new List<Transform>();
    [SerializeField] private List<Transform> vehiclesWithTick = new List<Transform>();
    public List<Tick> ticks = new List<Tick>();

    #endregion

    public void InitializeTimeManager()
    {
        trafficManager = GetComponent<TrafficManager>();
    }

    private void Update()
    {
        for (int i = 0; i < ticks.Count; i++)
        {
            ticks[i].timeTillDeparture -= Time.deltaTime;
        }

        RemoveOldTicks();
    }

    public void RemoveOldTicks()
    {
        List<Tick> ticksToRemove = new List<Tick>();

        for (int j = 0; j < ticks.Count; j++)
        {
            if (ticks[j].timeTillDeparture + ticks[j].GetTimeOfSlowestVehicleForCompletion(ticks[j].vehiclesInTick) < .1f)
            {
                ticksToRemove.Add(ticks[j]);
            }
        }

        if (ticksToRemove.Count > 0)
        {
            for (int o = 0; o < ticksToRemove.Count; o++)
            {
                ticks.Remove(ticksToRemove[o]);
            }

            if (ticks.Count > 0)
            {
                if (ticks[0].timeTillDeparture < 0) //If vehicle is on the intersection -> let it accelerate
                {
                    VehicleSpeedManager vehicleSMV = ticks[0].vehiclesInTick[0].GetComponent<VehicleSpeedManager>();

                    vehicleSMV.decelerate = false;
                    vehicleSMV.accelerate = true;
                    vehicleSMV.targetSpeed = vehicleSMV.vehicleSpeed;
                }
            }
        }
    }

    public void CheckIfNewTick()
    {
        vehiclesWithTick.Clear();
        potentialVehiclesWithoutTick.Clear();
        vehiclesWithoutTick.Clear();

        for (int i = 0; i < ticks.Count; i++)
        {
            for (int j = 0; j < ticks[i].vehiclesInTick.Count; j++)
            {
                vehiclesWithTick.Add(ticks[i].vehiclesInTick[j]);
            }
        }

        for (int i = 0; i < trafficManager.queue.Count; i++)
        {
            if (vehiclesWithTick.Contains(trafficManager.queue[i]) == false)
            {
                Transform vehicle = trafficManager.queue[i];
                int queueNumberVehicle = trafficManager.GetQueueNumberOfVehicle(street: vehicle.GetComponent<VehicleManager>().currentStreet, vehicleQueueNumber: int.MaxValue);
                int posNumberVehicle = trafficManager.GetPosNumberOfVehicle(vehicle: vehicle, street: null, vehicleQueueNumber: queueNumberVehicle);

                if (posNumberVehicle != 0)
                {
                    Transform previousVehicle = trafficManager.queues[queueNumberVehicle][posNumberVehicle - 1];
                    if (vehiclesWithTick.Contains(previousVehicle) == false)
                    {
                        vehiclesWithoutTick.Add(trafficManager.queue[i]);
                    }
                }

                potentialVehiclesWithoutTick.Add(trafficManager.queue[i]);
            }
        }

        if (potentialVehiclesWithoutTick.Count > 0)
        {
            CreateNewTick();
        }
    }

    public void CreateNewTick()
    {
        ticks.Add(null);

        Tick newTick = new Tick(newTrafficManager: trafficManager, myTimeManager: this, queueOfVehiclesWithoutTick: potentialVehiclesWithoutTick);

        for (int i = 0; i < ticks.Count; i++)
        {
            if (ticks[i] == null)
                ticks[i] = newTick;
        }

        CalculateNewTimesForTicks();
    }

    public void CalculateNewTimesForTicks()
    {
        for (int i = 0; i < ticks.Count; i++)
        {
            Tick tick = ticks[i];

            if(tick.timeTillDeparture >= 0)
            {
                tick.timeTillDeparture = tick.GetSlowestTime(tick.vehiclesInTick);
                tick.timeTillDepartureWhenCreated = tick.timeTillDeparture;

                tick.DecelerateVehicles(tick.vehiclesInTick);
            }
        }
    }
}


[System.Serializable]
public class Tick
{
    #region Variables

    private TrafficManager trafficManager;
    private TimeManager timeManager;

    public float timeTillDepartureWhenCreated;
    public float timeTillDeparture;

    public List<Transform> vehiclesInQueue;
    public List<Blockage> vehicleBlockInformation;
    public List<Transform> vehiclesInTick;

    #endregion

    public Tick(TrafficManager newTrafficManager, TimeManager myTimeManager, List<Transform> queueOfVehiclesWithoutTick)
    {
        trafficManager = newTrafficManager;
        timeManager = myTimeManager;
        vehiclesInQueue = new List<Transform>();
        vehiclesInTick = new List<Transform>();
        vehicleBlockInformation = new List<Blockage>();

        for (int i = 0; i < queueOfVehiclesWithoutTick.Count; i++)
        {
            Transform vehicle = queueOfVehiclesWithoutTick[i];
            vehiclesInQueue.Add(vehicle);
            vehicleBlockInformation.Add(GetBlockedAreas(vehicle));
        }

        for (int i = 0; i < vehiclesInQueue.Count; i++)
        {
            vehiclesInQueue[i].GetComponent<ParabolaController>().myTick = this;
        }

        List<Transform> vehiclesBestOption = new List<Transform>();

        for (int i = 0; i < vehiclesInQueue.Count; i++)
        {
            Transform testingVehicle = vehiclesInQueue[i];
            List<Transform> vehiclesPotentuallyAbleToDrive = new List<Transform>();
            List<Transform> vehiclesNextPotentuallyAbleToDrive = new List<Transform>();
            List<Transform> vehiclesAbleToDrive = new List<Transform>();
            vehiclesPotentuallyAbleToDrive.Add(testingVehicle);
            vehiclesAbleToDrive.Add(testingVehicle);

            for (int j = 0; j < vehiclesInQueue.Count; j++)
            {
                Transform comparingVehicle = vehiclesInQueue[j];

                if(testingVehicle != comparingVehicle)
                {
                    bool blocking = false;

                    float timeTestingVehicle = testingVehicle.GetComponent<ParabolaController>().timeTillPartDestination;
                    float timeComparingVehicle = comparingVehicle.GetComponent<ParabolaController>().timeTillPartDestination;
                    float timeDifference = Mathf.Abs(timeTestingVehicle - timeComparingVehicle);

                    if (timeDifference > 2)
                    {
                        blocking = true;
                    }
                    else
                    {
                        for (int k = 0; k < 4; k++)
                        {
                            if (vehicleBlockInformation[i].areasBlocked[k] == true && vehicleBlockInformation[j].areasBlocked[k] == true)
                            {
                                blocking = true;
                            }
                        }
                    }

                    if (blocking == true)
                    {
                        vehicleBlockInformation[i].vehiclesBlocked++;
                    }
                    else
                    {
                        vehiclesPotentuallyAbleToDrive.Add(comparingVehicle);
                    }
                }
            }

            //How the most potential vehicles can drive together (WITH vehicle i)
            for (int l = 0; l < vehiclesPotentuallyAbleToDrive.Count; l++)
            {
                Transform comparingVehicle = vehiclesPotentuallyAbleToDrive[l];

                vehiclesNextPotentuallyAbleToDrive.Clear();
                vehiclesNextPotentuallyAbleToDrive.Add(testingVehicle);

                if (testingVehicle != comparingVehicle)
                {
                    vehiclesNextPotentuallyAbleToDrive.Add(comparingVehicle);
                    for (int m = 0; m < vehiclesPotentuallyAbleToDrive.Count; m++)
                    {
                        Transform nextComparingVehicle = vehiclesPotentuallyAbleToDrive[m];
                        if(testingVehicle != comparingVehicle && comparingVehicle != nextComparingVehicle)
                        {
                            bool blocking = false;

                            for (int n = 0; n < 4; n++)
                            {
                                if (vehicleBlockInformation[l].areasBlocked[n] == true && vehicleBlockInformation[l].areasBlocked[n] == true)
                                {
                                    blocking = true;
                                }
                            }

                            if (blocking == true)
                            {
                                vehicleBlockInformation[i].vehiclesBlocked++;
                            }
                            else
                            {
                                vehiclesNextPotentuallyAbleToDrive.Add(comparingVehicle);
                            }
                        }
                    }
                }

                if(vehiclesNextPotentuallyAbleToDrive.Count > vehiclesAbleToDrive.Count)
                {
                    vehiclesAbleToDrive = vehiclesNextPotentuallyAbleToDrive;
                }
            }

            if(vehiclesAbleToDrive.Count > vehiclesBestOption.Count)
            {
                vehiclesBestOption = vehiclesAbleToDrive;
            }
        }

        vehiclesInTick = vehiclesBestOption;

        RearangeTicks();
    }

    public void RearangeTicks()
    {
        float currentTickTimeTillDeparture = GetCurrentTimeTillDeparture();

        for (int i = 0; i < timeManager.ticks.Count - 1; i++)
        {
            float tickTimeTillDeparture = timeManager.ticks[i].timeTillDeparture;

            if (currentTickTimeTillDeparture < tickTimeTillDeparture)
            {
                for (int j = timeManager.ticks.Count - 2; j >= i; j--)
                {
                    timeManager.ticks[j + 1] = timeManager.ticks[j];
                    timeManager.ticks[j] = null;
                }

                timeManager.ticks[i] = this;

                break;
            }
        }
    }

    public float GetCurrentTimeTillDeparture()
    {
        float currentTickTimeTillDeparture;

        Transform vehicle = vehiclesInTick[0];

        int queueNumber = vehicle.GetComponent<ParabolaController>().queueNumber;
        int posNumber = trafficManager.GetPosNumberOfVehicle(vehicle: vehicle, street: null, vehicleQueueNumber: queueNumber);

        if(posNumber == 0)
        {
            currentTickTimeTillDeparture = vehicle.GetComponent<ParabolaController>().timeTillPartDestination;
        }
        else
        {
            currentTickTimeTillDeparture = GetSlowestTime(vehiclesInTick);
        }


        return currentTickTimeTillDeparture;
    }

    public void DecelerateVehicles(List<Transform> vehicles)
    {
        for (int i = 0; i < vehicles.Count; i++)
        {
            vehicles[i].GetComponent<VehicleSpeedManager>().CalculateDecelerationTillTick(timeTillDeparture);
        }
    }

    public float GetSlowestTime(List<Transform> vehicles)
    {
        float time = int.MinValue;

        for (int i = 0; i < vehicles.Count; i++)
        {
            if(time < vehicles[i].GetComponent<ParabolaController>().timeTillPartDestination)
            {
                time = vehicles[i].GetComponent<ParabolaController>().timeTillPartDestination;
            }
        }

        int previousTickPos = GetPreviousTickPosNumber();

        if (previousTickPos >= 0)
        {
            float timePreviousTickSlowestDriveTrough = GetTimeOfSlowestVehicleForCompletion(timeManager.ticks[previousTickPos].vehiclesInTick);
            float timeDifference = timeManager.ticks[previousTickPos].timeTillDeparture + timePreviousTickSlowestDriveTrough;

            if (time - timeDifference < 0)
            {
                time = timeDifference;
            }
        }

        return time;
    }

    public int GetPreviousTickPosNumber()
    {
        int pos = -1;

        if (timeManager.ticks.Count > 0)
        {
            for (int i = 1; i < timeManager.ticks.Count; i++)
            {
                if (timeManager.ticks[i] == this)
                {
                    pos = i -1;
                }
            }
        }

        return pos;
    }

    public float GetTimeOfSlowestVehicleForCompletion(List<Transform> vehicles)
    {
        float slowestTime = 9999;

        float leftTurnLength = 11.7f;
        float NoTurnLength = 11f;
        float RightTurnLength = 6.1f;

        for (int i = 0; i < vehicles.Count; i++)
        {
            Transform vehicle = vehicles[i];
            VehicleMover vehicleMV = vehicle.GetComponent<VehicleMover>();
            VehicleSpeedManager vehicleSMV = vehicle.GetComponent<VehicleSpeedManager>();
            float vehicleSpeed;
            float vehicleTime = 9999;

            if (vehicleSMV.targetSpeed != 0)
            {
                vehicleSpeed = vehicleSMV.targetSpeed;
            }
            else
            {
                vehicleSpeed = vehicle.GetComponent<ParabolaController>().currentSpeed;
            }

            if (vehicleMV.directions[vehicleMV.turnsDone] == 'l')
            {
                vehicleTime = leftTurnLength / vehicleSpeed;
            }
            else if(vehicleMV.directions[vehicleMV.turnsDone] == 's')
            {
                vehicleTime = NoTurnLength / vehicleSpeed;
            }
            else if (vehicleMV.directions[vehicleMV.turnsDone] == 'r')
            {
                vehicleTime = RightTurnLength / vehicleSpeed;
            }

            if(slowestTime > vehicleTime)
            {
                slowestTime = vehicleTime;
            }
        }

        return slowestTime;
    }

    public Blockage GetBlockedAreas(Transform vehicle)
    {
        Blockage blockedAreas = new Blockage(area0Blocked: false, area1Blocked: false, area2Blocked: false, area3Blocked: false);
        int entranceArea = GetEntranceArea(vehicle: vehicle);
        int exitArea = GetExitArea(vehicle: vehicle, entranceArea: entranceArea);

        for (int i = 0; i < 4; i++)
        {
            //Straight
            if (entranceArea == i && exitArea == i)
            {
                blockedAreas.areasBlocked[entranceArea] = true;
                return blockedAreas;
            }

            //Right
            if ((entranceArea == i && entranceArea == exitArea + 1) || exitArea == 3)
            {
                blockedAreas.areasBlocked[entranceArea] = true;
                blockedAreas.areasBlocked[exitArea] = true;
                return blockedAreas;
            }

            //Left
            if ((entranceArea == i && entranceArea == exitArea - 2) || exitArea == 0 || exitArea == 1)
            {
                int number = entranceArea;
                number -= 1;
                if (number < 0)
                {
                    number = 3;
                }

                blockedAreas.areasBlocked[entranceArea] = true;
                blockedAreas.areasBlocked[number] = true;
                blockedAreas.areasBlocked[exitArea] = true;
                return blockedAreas;
            }
        }

        return blockedAreas;
    }

    public int GetEntranceArea(Transform vehicle)
    {
        //Queue Grade -> (0) -> Etrance Area = 0
        //Queue Rechts -> (1) -> Etrance Area = 1
        //Queue Zurück -> (2) -> Etrance Area = 2
        //Queue Links -> (3) -> Etrance Area = 3


        return trafficManager.GetQueueNumberOfVehicle(street: vehicle.GetComponent<VehicleManager>().currentStreet, vehicleQueueNumber: int.MaxValue);
    }

    public int GetExitArea(Transform vehicle, int entranceArea)
    {
        //Left = entranceArea - 2
        //Straigt = entranceArea - 1
        //Right = entranceArea

        int exitArea = entranceArea;
        VehicleMover MV = vehicle.GetComponent<VehicleMover>();
        int turnOnThisIntersection = MV.turnsDone;

        char turn = MV.directions[turnOnThisIntersection];

        if (turn == 'l')
        {
            exitArea -= 1;
            if (exitArea < 0)
            {
                exitArea = 3;
            }
            exitArea -= 1;
            if (exitArea < 0)
            {
                exitArea = 3;
            }
        }
        else if (turn == 's')
        {
            exitArea -= 1;
            if (exitArea < 0)
            {
                exitArea = 3;
            }
        }
        else if (turn == 'r')
        {
            exitArea = entranceArea;
        }

        return exitArea;
    }

    [System.Serializable]
    public class Blockage
    {
        #region Variables

        public int waitedTimes;
        public int vehiclesBlocked;

        public List<bool> areasBlocked;

        #endregion

        public Blockage(bool area0Blocked, bool area1Blocked, bool area2Blocked, bool area3Blocked)
        {
            areasBlocked = new List<bool>();

            areasBlocked.Add(false);
            areasBlocked.Add(false);
            areasBlocked.Add(false);
            areasBlocked.Add(false);

            areasBlocked[0] = area0Blocked;
            areasBlocked[1] = area1Blocked;
            areasBlocked[2] = area2Blocked;
            areasBlocked[3] = area3Blocked;
        }
    }
}