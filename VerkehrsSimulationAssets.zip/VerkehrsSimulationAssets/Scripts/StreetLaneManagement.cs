﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StreetLaneManagement : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The StreetLaneManagement script is a key component in the infrastructure
    //It makes the connection between street lanes and vehicles possible
    //It stores how many and which vehicles are on the street
    //It is located on each street lane

    #endregion

    #region Variables

    public Transform exit;
    public Transform entrance;
    public Transform intersectionAtEntrance;
    public Transform intersectionAtExit;

    public int vehicleNumberOnStreet;

    public List<Transform> vehiclesOnStreet;

    #endregion

    public void DetectConnectionPoints()
    {
        RaycastHit hit;

        Vector3 centerPos = GetComponent<Renderer>().bounds.center;

        if (Physics.Raycast(origin: centerPos, direction: transform.right, hitInfo: out hit, maxDistance: transform.lossyScale.x / 2))
        {
            CheckIfConnectionPoint(connectionPoint: hit.transform);
        }

        if (Physics.Raycast(origin: centerPos, direction: -transform.right, hitInfo: out hit, maxDistance: transform.lossyScale.x / 2))
        {
            CheckIfConnectionPoint(connectionPoint: hit.transform);
        }
    }

    public void DetectConnectionPointsCurve()
    {
        BoxCollider[] endOfLaneColliders = GetComponents<BoxCollider>();

        RaycastHit hit;

        foreach (BoxCollider collider in endOfLaneColliders)
        {
            Vector3 colliderPos = new Vector3();
            colliderPos.y = transform.position.y;

            if (transform.eulerAngles.y == 0)
            {
                colliderPos.x = transform.position.x + (1 * (collider.center.x * transform.localScale.x));
                colliderPos.z = transform.position.z - (1 * (collider.center.y * transform.localScale.y));
            }

            if (transform.eulerAngles.y == 180)
            {
                colliderPos.x = transform.position.x - (1 * (collider.center.x * transform.localScale.x));
                colliderPos.z = transform.position.z + (1 * (collider.center.y * transform.localScale.y));
            }

            if (transform.eulerAngles.y == 90)
            {
                colliderPos.x = transform.position.x - (1 * (collider.center.y * transform.localScale.y));
                colliderPos.z = transform.position.z - (1 * (collider.center.x * transform.localScale.x));
            }

            if (transform.eulerAngles.y == 270)
            {
                colliderPos.x = transform.position.x + (1 * (collider.center.y * transform.localScale.y));
                colliderPos.z = transform.position.z + (1 * (collider.center.x * transform.localScale.x));
            }

            Collider[] collisionCollider = Physics.OverlapSphere(position: colliderPos, radius: .1f);

            foreach (Collider collision in collisionCollider)
            {
                CheckIfConnectionPoint(connectionPoint: collision.transform);
            }
        }
    }

    private void CheckIfConnectionPoint(Transform connectionPoint)
    {
        if (connectionPoint.tag == "Entrance")
        {
            entrance = connectionPoint;
            intersectionAtEntrance = entrance.parent.parent;
        }

        if (connectionPoint.tag == "Exit")
        {
            exit = connectionPoint;
            intersectionAtExit = exit.parent.parent;
        }
    }

    public void AdVehicle(Transform newVehicle)
    {
        vehicleNumberOnStreet++;
        vehiclesOnStreet.Add(item: newVehicle);
    }

    public void RemoveVehicle(Transform oldVehicle)
    {
        vehicleNumberOnStreet--;
        vehiclesOnStreet.Remove(item: oldVehicle);
    }
}