﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrafficManager : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The TrafficManager script is essential for the TimeManager
    //It creates queues for each street lane with the approaching vehicles
    //It is located on the intersection

    #endregion

    #region Variables

    public IntersectionManager intersectionManager;

    public Transform entranceGrade;
    public Transform entranceRechts;
    public Transform entranceZurück;
    public Transform entranceLinks;

    public List<Transform> queueGrade;
    public List<Transform> queueRechts;
    public List<Transform> queueZurück;
    public List<Transform> queueLinks;
    public List<Transform> queue = new List<Transform>();
    public List<Transform> entrances = new List<Transform>(4);
    public List<List<Transform>> queues = new List<List<Transform>>(4);

    #endregion

    public void AssignEntrances()
    {
        if (intersectionManager.streets[0] != null)
        {
            if (intersectionManager.streetLanes[0].GetComponent<StreetLaneManagement>().intersectionAtEntrance == transform)
            {
                entranceLinks = intersectionManager.streetLanes[0];
            }
            else if (intersectionManager.streetLanes[1].GetComponent<StreetLaneManagement>().intersectionAtEntrance == transform)
            {
                entranceLinks = intersectionManager.streetLanes[1];
            }
        }
        if (intersectionManager.streets[1] != null)
        {
            if (intersectionManager.streetLanes[2].GetComponent<StreetLaneManagement>().intersectionAtEntrance == transform)
            {
                entranceGrade = intersectionManager.streetLanes[2];
            }
            else if (intersectionManager.streetLanes[3].GetComponent<StreetLaneManagement>().intersectionAtEntrance == transform)
            {
                entranceGrade = intersectionManager.streetLanes[3];
            }
        }
        if (intersectionManager.streets[2] != null)
        {
            if (intersectionManager.streetLanes[4].GetComponent<StreetLaneManagement>().intersectionAtEntrance == transform)
            {
                entranceRechts = intersectionManager.streetLanes[4];
            }
            else if (intersectionManager.streetLanes[5].GetComponent<StreetLaneManagement>().intersectionAtEntrance == transform)
            {
                entranceRechts = intersectionManager.streetLanes[5];
            }
        }
        if (intersectionManager.streets[3] != null)
        {
            if (intersectionManager.streetLanes[6].GetComponent<StreetLaneManagement>().intersectionAtEntrance == transform)
            {
                entranceZurück = intersectionManager.streetLanes[6];
            }
            else if (intersectionManager.streetLanes[7].GetComponent<StreetLaneManagement>().intersectionAtEntrance == transform)
            {
                entranceZurück = intersectionManager.streetLanes[7];
            }
        }

        entrances.Add(entranceGrade);
        entrances.Add(entranceRechts);
        entrances.Add(entranceZurück);
        entrances.Add(entranceLinks);

        queueGrade = new List<Transform>();
        queueRechts = new List<Transform>();
        queueZurück = new List<Transform>();
        queueLinks = new List<Transform>();

        queues.Add(queueGrade);
        queues.Add(queueRechts);
        queues.Add(queueZurück);
        queues.Add(queueLinks);
    }

    public int GetQueueNumberOfVehicle(Transform street, int vehicleQueueNumber)
    {
        int queueNumber = 99;

        if (street != null)
        {
            for (int i = 0; i < entrances.Count; i++)
            {
                if (entrances[i] == street)
                {
                    queueNumber = i;
                }
            }
        }

        if (vehicleQueueNumber != int.MaxValue)
        {
            queueNumber = vehicleQueueNumber;
        }

        return queueNumber;
    }

    public int GetPosNumberOfVehicle(Transform vehicle, Transform street, int vehicleQueueNumber)
    {
        int queueNumber = 99;
        int posNumber = 99;

        if (street != null)
        {
            for (int i = 0; i < entrances.Count; i++)
            {
                if (entrances[i] == street)
                    queueNumber = i;
            }
        }

        if (vehicleQueueNumber != int.MaxValue)
        {
            queueNumber = vehicleQueueNumber;
        }

        for (int i = 0; i < queues[queueNumber].Count; i++)
        {
            if (queues[queueNumber][i] == vehicle)
            {
                posNumber = i;
            }
        }

        return posNumber;
    }

    public void GetQueueOrder(Transform street, int vehicleQueueNumber)
    {
        int queueNumber = GetQueueNumberOfVehicle(street, vehicleQueueNumber);
        List<Transform> queue;
        Transform entrance;

        queue = queues[queueNumber];
        entrance = entrances[queueNumber];

        queue.Clear();

        for (int i = 0; i < entrance.GetComponent<StreetLaneManagement>().vehicleNumberOnStreet; i++)
        {
            Transform vehicle = entrance.GetComponent<StreetLaneManagement>().vehiclesOnStreet[i];
            ParabolaController vehiclePC = vehicle.GetComponent<ParabolaController>();
            VehicleMover vehicleMV = vehicle.GetComponent<VehicleMover>();
            float vehicleDistanceToEntrance = Vector3.Distance(vehicle.position, vehicleMV.posEntrance);

            if (queue.Count > 0)
            {
                int queueCount = queue.Count;
                for (int j = 0; j < queueCount; j++)
                {
                    Transform vehicleInList = queue[j];
                    ParabolaController vehiclePCInList = vehicleInList.GetComponent<ParabolaController>();
                    VehicleMover vehicleMVInList = vehicleInList.GetComponent<VehicleMover>();
                    float vehicleInListDistanceToEntrance = Vector3.Distance(vehicleInList.position, vehicleMVInList.posEntrance);


                    if ((vehiclePC.isOnIntersection == true && vehiclePCInList.isOnIntersection == true) || (vehiclePC.isOnIntersection == false && vehiclePCInList.isOnIntersection == false) || (vehiclePC.isOnIntersection == true && vehiclePCInList.isOnIntersection == false))
                    {
                        if (vehicleDistanceToEntrance < vehicleInListDistanceToEntrance || (vehiclePC.isOnIntersection == true && vehiclePCInList.isOnIntersection == false))
                        {
                            queue.Add(null);

                            for (int k = queue.Count - 2; k >= j; k--)
                            {
                                queue[k + 1] = queue[k];
                            }

                            queue[j] = vehicle;

                            break;
                        }
                    }
                }
            }

            if (queue.Contains(vehicle) == false)
            {
                queue.Add(vehicle);
            }
        }

        entrance.GetComponent<StreetLaneManagement>().vehiclesOnStreet.Clear();
        for (int l = 0; l < queue.Count; l++)
        {
            entrance.GetComponent<StreetLaneManagement>().vehiclesOnStreet.Add(queue[l]);
        }

        SetQueue();
    }

    public void SetQueue()
    {
        CalculateTimeTillEndOfStreet();

        queue.Clear();

        //For each queue
        for (int i = 0; i < queues.Count; i++)
        {
            //For each vehicle in the Queue[i]
            for (int j = 0; j < queues[i].Count; j++)
            {
                Transform vehicle = queues[i][j].transform;
                ParabolaController vehiclePC = vehicle.GetComponent<ParabolaController>();
                float vehicleTimeToEntrance = vehiclePC.timeTillPartDestination;

                if (vehicleTimeToEntrance != 0)
                {
                    if (queue.Contains(vehicle) == false)
                    {
                        if (queue.Count > 0)
                        {
                            for (int k = 0; k < queue.Count; k++)
                            {
                                Transform vehicleInList = queue[k];
                                ParabolaController vehiclePCInList = vehicleInList.GetComponent<ParabolaController>();
                                float vehicleInListTimeToEntrance = vehiclePCInList.timeTillPartDestination;

                                //Vehicle (queue[k]) is in front of vehicle (queues[i][j]) 
                                if ((vehiclePC.isOnIntersection == false && vehiclePCInList.isOnIntersection == true) || vehicleTimeToEntrance > vehicleInListTimeToEntrance)
                                {

                                }
                                else
                                {
                                    queue.Add(null);
                                    for (int l = queue.Count - 2; l >= k; l--)
                                    {
                                        queue[l + 1] = queue[l];
                                    }

                                    queue[k] = vehicle;

                                    break; //Vehicle was added to the list, continue
                                }
                            }

                            if (queue.Contains(vehicle) == false)
                            {
                                queue.Add(vehicle);
                            }

                        }
                        else
                        {
                            queue.Add(vehicle);
                        }
                    }
                }
            }
        }

        if (queue.Count > 0)
        {
            TimeManager timeManager = GetComponent<TimeManager>();
            timeManager.CheckIfNewTick();
        }
    }

    public void CalculateTimeTillEndOfStreet()
    {
        //For each queue
        for (int i = 0; i < queues.Count; i++)
        {
            //For each vehicle in the Queue[i]
            for (int j = 0; j < queues[i].Count; j++)
            {
                Transform vehicle = queues[i][j];
                ParabolaController vehiclePC = vehicle.GetComponent<ParabolaController>();
                VehicleManager vehicleVM = vehicle.GetComponent<VehicleManager>();
                int vehicleQueueNumber = vehiclePC.queueNumber;
                float vehicleAnimationTime = vehiclePC.animationTime;
                float vehicleCurrentSpeed = vehiclePC.currentSpeed;

                if (vehiclePC.parabolaFly.GetDuration() != 0 && vehiclePC.myTick != null)
                {
                    if (vehiclePC.myTick.timeTillDeparture > 0)
                    {
                        vehiclePC.timeTillPartDestination = vehiclePC.myTick.timeTillDeparture;
                    }
                    else
                    {
                        if (vehiclePC.trafficManager != null && vehicleQueueNumber != 99)
                        {
                            Transform firstVehicle = queues[vehicleQueueNumber][0];

                            if (firstVehicle == vehicle)
                            {
                                vehiclePC.timeTillPartDestination = vehiclePC.parabolaFly.GetDuration() - vehicleAnimationTime;
                                vehicle.GetComponent<VehicleSpeedManager>().CalculateDecelerationTillTick(timeTillDeparture: vehiclePC.timeTillPartDestination);
                                return;
                            }

                            Transform previousVehicle;

                            previousVehicle = queues[vehicleQueueNumber][GetPosNumberOfVehicle(vehicle, null, vehicleQueueNumber) - 1];

                            ParabolaController previousPC = previousVehicle.GetComponent<ParabolaController>();
                            float previousVehicleSpeed = previousPC.vehicleSpeedManager.targetSpeed;
                            float distanceTillHit;

                            StreetManagement streetManagement = vehicleVM.currentStreet.parent.GetComponent<StreetManagement>();
                            if (streetManagement.isCurve == false)
                            {
                                distanceTillHit = Vector3.Distance(previousVehicle.position, vehicle.position) - vehicleVM.intersectionVehicleInformation.vehicleLength - vehiclePC.safetyDistance;
                            }
                            else
                            {
                                float streetLengthDifference = streetManagement.streetLenght * (previousPC.GetAnimationPercentage() - vehiclePC.GetAnimationPercentage());
                                distanceTillHit = streetLengthDifference - vehicleVM.intersectionVehicleInformation.vehicleLength - vehiclePC.safetyDistance;
                            }

                            float timeTillBehindPriviousVehicle;
                            timeTillBehindPriviousVehicle = Mathf.Abs(distanceTillHit / (vehicleCurrentSpeed - previousVehicleSpeed));

                            if (previousPC.timeTillPartDestination - timeTillBehindPriviousVehicle > 0)
                            {
                                VehicleMover vehicleMV = vehicle.GetComponent<VehicleMover>();

                                vehicleAnimationTime = vehiclePC.GetDuration() * vehiclePC.GetAnimationPercentage();

                                float distanceTillEntrance = Vector3.Distance(vehiclePC.GetPositionAtTime(timeTillBehindPriviousVehicle + vehicleAnimationTime), vehicleMV.posEntrance);
                                float timeForDistanceWithNewSpeed = distanceTillEntrance / previousPC.vehicleSpeedManager.targetSpeed;

                                vehiclePC.timeTillPartDestination = timeTillBehindPriviousVehicle + timeForDistanceWithNewSpeed;
                                vehicle.GetComponent<VehicleSpeedManager>().CalculateDecelerationTillTick(timeTillDeparture: vehiclePC.timeTillPartDestination);

                                return;
                            }
                        }

                        vehiclePC.timeTillPartDestination = vehiclePC.parabolaFly.GetDuration() - vehicleAnimationTime;
                        vehicle.GetComponent<VehicleSpeedManager>().CalculateDecelerationTillTick(timeTillDeparture: vehiclePC.timeTillPartDestination);
                    }
                }
            }
        }
    }
}