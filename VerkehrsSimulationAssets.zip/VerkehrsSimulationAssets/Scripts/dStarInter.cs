﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class dStarInter : MonoBehaviour
{
    #region Author

    //This script was created by Bastian Steffensen

    #endregion

    #region Description

    //The dStarInter script is important for the DStarAlgorithm2 script
    //It stores information for the DStarAlgorithm
    //It is located on the intersection

    #endregion

    #region Variables

    public List<Transform> neighborStreetList;// Liste der anliegenden Straßen
    public List<Transform> neighborInterList;// Liste der nächsten Kreuzungen(keine Kreuzungen dazwischen)
    public List<Transform> tempNeighbor;
    public Transform Grade;
    public Transform Links;
    public Transform Zurück;
    public Transform Rechts;
    public dStarSave save;
    public int intersectionBusyness;

    RaycastHit hit;

    #endregion

    public void InitializeDStarIntersections()
    {
        neighborStreetList = new Transform[4].ToList();
        tempNeighbor = new Transform[4].ToList();

        if (Physics.Raycast(transform.position, transform.forward, out hit, 6))
        {
            neighborStreetList[2] = hit.transform;
            Grade = hit.transform;
        }
        if (Physics.Raycast(transform.position, -transform.forward, out hit, 6))
        {
            neighborStreetList[0] = hit.transform;
            Zurück = hit.transform;
        }
        if (Physics.Raycast(transform.position, transform.right, out hit, 6))
        {
            neighborStreetList[3] = hit.transform;
            Rechts = hit.transform;
        }
        if (Physics.Raycast(transform.position, -transform.right, out hit, 6))
        {
            neighborStreetList[1] = hit.transform;
            Links = hit.transform;
        }

        dStarSave intersectionSave = ScriptableObject.CreateInstance("dStarSave") as dStarSave;
        save = intersectionSave;
        save.intersection = transform;
        FindNeighborIntersection();// Startet den IEnumerator findNeighborIntersection
    }

    public void FindNeighborIntersection()// Findet alle Kreuzungen, welche nur mit einer Straße verbunden sind
    {
        for (int i = 0; i < 4; i++)
        {
            neighborInterList.Add(null);
        }

        if(Zurück != null)
        {
            for (int i = 0; i < Zurück.GetComponent<StreetManagement>().intersection.Count; i++)
            {
                if (Zurück.GetComponent<StreetManagement>().intersection[i] != transform)
                {
                    if (!neighborInterList.Contains(Zurück.GetComponent<StreetManagement>().intersection[i]))
                    {
                        // Kreuzung wird abgespeichert, wenn sie noch nicht abgespeichert ist und sie mit derselben Straße verbunden ist
                        neighborInterList[0] = Zurück.GetComponent<StreetManagement>().intersection[i];
                    }
                }
            }
        }

        if(Links != null)
        {
            for (int i = 0; i < Links.GetComponent<StreetManagement>().intersection.Count; i++)
            {
                if (Links.GetComponent<StreetManagement>().intersection[i] != transform)
                {
                    if (!neighborInterList.Contains(Links.GetComponent<StreetManagement>().intersection[i]))
                    {
                        // Kreuzung wird abgespeichert, wenn sie noch nicht abgespeichert ist und sie mit derselben Straße verbunden ist
                        neighborInterList[1] = Links.GetComponent<StreetManagement>().intersection[i];
                    }
                }
            }
        }

        if (Grade != null)
        {
            for (int i = 0; i < Grade.GetComponent<StreetManagement>().intersection.Count; i++)
            {
                if (Grade.GetComponent<StreetManagement>().intersection[i] != transform)
                {
                    if (!neighborInterList.Contains(Grade.GetComponent<StreetManagement>().intersection[i]))
                    {
                        // Kreuzung wird abgespeichert, wenn sie noch nicht abgespeichert ist und sie mit derselben Straße verbunden ist
                        neighborInterList[2] = Grade.GetComponent<StreetManagement>().intersection[i];
                    }
                }
            }
        }

        if (Rechts != null)
        {
            for (int i = 0; i < Rechts.GetComponent<StreetManagement>().intersection.Count; i++)
            {
                if (Rechts.GetComponent<StreetManagement>().intersection[i] != transform)
                {
                    if (!neighborInterList.Contains(Rechts.GetComponent<StreetManagement>().intersection[i]))
                    {
                        // Kreuzung wird abgespeichert, wenn sie noch nicht abgespeichert ist und sie mit derselben Straße verbunden ist
                        neighborInterList[3] = Rechts.GetComponent<StreetManagement>().intersection[i];
                    }
                }
            }
        }

        for (int i = 0; i < neighborInterList.Count; i++)
        {
            save.neighbors.Add(neighborInterList[i]);
        }
    }
}