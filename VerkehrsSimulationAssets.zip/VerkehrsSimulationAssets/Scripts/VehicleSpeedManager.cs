﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VehicleSpeedManager : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The VehicleSpeedManager script is essential for the vehicle
    //It checks if there is any other vehicle to near in front of the vehicle
    //It calculates the amout of deceleration for the vehicle to get the vehicle where it has to be at the right time
    //It is located on the vehicle

    #endregion

    #region Variables

    private VehicleManager vehicleManager;
    private ParabolaController parabolaController;

    public float acceleration = 6;
    public float deceleration;
    public float targetSpeed;
    public float vehicleSpeed;

    public bool accelerate;
    public bool decelerate;
    public bool speedControlledByIntersection;

    #endregion

    public void InitializeVehicleSpeedManager()
    {
        vehicleManager = GetComponent<VehicleManager>();
        parabolaController = GetComponent<ParabolaController>();

        vehicleSpeed = parabolaController.currentSpeed;
    }

    public void CalculateDecelerationTillTick(float timeTillDeparture)
    {
        parabolaController.myTick.timeTillDeparture = parabolaController.timeTillPartDestination;

        Vector3 entrancePos = new Vector3(GetComponent<VehicleMover>().posEntrance.x, transform.position.y, GetComponent<VehicleMover>().posEntrance.z);

        float distanceTillEntrance;
        StreetManagement streetManagement = vehicleManager.currentStreet.parent.GetComponent<StreetManagement>();
        if (streetManagement.isCurve == false)
        {
            distanceTillEntrance = Vector3.Distance(transform.position, entrancePos);
        }
        else
        {
            distanceTillEntrance = streetManagement.streetLenght * (1f - parabolaController.GetAnimationPercentage()) * 5;
        }

        #region extendedDeceleration

        //float newSpeed = distanceTillEntrance / timeTillDeparture;
        //float decelerationDistance = 5f;

        //if (decelerationDistance > distanceTillEntrance)
        //    decelerationDistance = distanceTillEntrance * .9f;

        //float distanceWithNewSpeed = distanceTillEntrance - decelerationDistance;
        //float timeForDecelerationDistance = decelerationDistance / ((parabolaController.currentSpeed + newSpeed) / 2);

        //deceleration = (newSpeed - parabolaController.currentSpeed) / timeForDecelerationDistance;

        //newSpeed = distanceWithNewSpeed / (timeTillDeparture - timeForDecelerationDistance);

        #endregion

        #region InstantDeceleration

        float newSpeed = distanceTillEntrance / timeTillDeparture;
        parabolaController.currentSpeed = newSpeed;

        #endregion

        targetSpeed = newSpeed;
        parabolaController.myTick.timeTillDeparture = timeTillDeparture;

        accelerate = false;
        decelerate = true;
        speedControlledByIntersection = true;
    }

    public int GetSpeedChangingCase()
    {
        int caseNumber = 0;

        if (speedControlledByIntersection == true && accelerate == true)
        {
                caseNumber = 1;
        }
        else if (speedControlledByIntersection == true && decelerate == true)
        {
                caseNumber = 2;
        }

        return caseNumber;
    }
}
