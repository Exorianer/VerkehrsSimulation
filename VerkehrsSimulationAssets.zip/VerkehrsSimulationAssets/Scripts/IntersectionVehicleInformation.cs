﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "VehicleInformation", menuName = "Create new VehicleInformation")]
public class IntersectionVehicleInformation : ScriptableObject
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //A IntersectionVehicleInformation ScriptableObject exists to store information depending on the vehicle
    //Other Scripts can access it in the VehicleManager to get the information

    #endregion

    #region Variables

    public float vehicleLength;
    public int vehicleEntrance;
    public int vehicleExit;

    #endregion
}
