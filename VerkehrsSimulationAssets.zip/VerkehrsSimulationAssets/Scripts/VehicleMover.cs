﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VehicleMover : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The VehicleMover script is important for the vehicle
    //It stores the information about the path to the destination and initialzes if needed the new movement direction
    //It is located on the vehicle

    #endregion

    #region Variables

    private ParabolaController parabolaController;
    private VehicleManager vehicleManager;

    [SerializeField] private Transform startPoint;
    [SerializeField] private Transform vertexPoint;
    [SerializeField] private Transform endPoint;

    public Vector3 posExit;
    public Vector3 posVertex;
    public Vector3 posEntrance;

    public int turnsDone;

    public bool pathSuccessfullyCreated;

    public List<char> directions = new List<char>();

    #endregion

    public void InitializeVehicleMover()
    {
        parabolaController = GetComponent<ParabolaController>();
        vehicleManager = GetComponent<VehicleManager>();
    }

    public void SetPath(List<char> path)
    {
        directions = path;

        pathSuccessfullyCreated = true;

        vehicleManager.nextIntersection.GetComponent<IntersectionManager>().DriveToEntrance(vehicle: transform);
    }

    public void TurnDone()
    {
        if(turnsDone < directions.Count - 1)
            turnsDone++;
    }

    public void SetPosition(Vector3 pos_StartPoint, Vector3 pos_VertexPoint, Vector3 pos_EndPoint, bool drivingToEntrance)
    {
        startPoint.position = pos_StartPoint;
        vertexPoint.position = pos_VertexPoint;
        endPoint.position = pos_EndPoint;

        posEntrance = pos_EndPoint;
        posVertex = pos_VertexPoint;
        posExit = pos_StartPoint;

        parabolaController.CreateParabola();
        InitializeMovement();
    }

    public void InitializeMovement()
    {
        parabolaController.RefreshTransforms();
    }
}
