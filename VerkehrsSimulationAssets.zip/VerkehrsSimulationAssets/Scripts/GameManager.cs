﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The GameManager script is needed for step-by-step initialization for the infrastructure
    //First it saves all infrastructure elements in lists
    //Then it lets check the infrastructure for all it's needed components
    //It is located on a seperate GameObject called "GeneralSettings"

    #endregion

    #region Variables

    public static GameManager instance;

    [SerializeField] private Transform vehicleParent;
    [SerializeField] private Transform intersectionParent;
    [SerializeField] private Transform streetParent;

    public float globalSafetyDistance;

    public List<Transform> intersections;
    public List<Transform> streets;
    public List<Transform> streetLanes;

    #endregion

    private void Awake()
    {
        instance = this;
    }

    private void Start()
    {
        InitializeSimulation();
    }

    private void InitializeSimulation()
    {
        GetIntersections();
        GetStreets();
        GetStreetLanes();

        InitializeStreetLanes();
        InitializeStreets();
        InitializeIntersections();

        InitializeVehicles();
    }

    #region GetInfrastructure
    public void GetIntersections()
    {
        foreach (Transform intersection in intersectionParent)
        {
            if (intersection.gameObject.activeSelf == true)
            {
                intersections.Add(intersection);
            }
        }
    }

    public void GetStreets()
    {
        foreach (Transform street in streetParent)
        {
            if (street.gameObject.activeSelf == true)
            {
                streets.Add(street);
            }
        }
    }

    public void GetStreetLanes()
    {
        foreach (Transform street in streets)
        {
            streetLanes.Add(street.GetChild(0));
            streetLanes.Add(street.GetChild(1));
        }
    }
    #endregion

    #region InitializeInfrastructure
    public void InitializeIntersections()
    {
        foreach (Transform intersection in intersections)
        {
            intersection.GetComponent<dStarInter>().InitializeDStarIntersections();
            intersection.GetComponent<IntersectionManager>().InitializeIntersectionManager();
            intersection.GetComponent<IntersectionManager>().DetectConnectingStreets();
            intersection.GetComponent<IntersectionManager>().DetectSensors();
            intersection.GetComponent<TrafficManager>().AssignEntrances();
            intersection.GetComponent<TimeManager>().InitializeTimeManager();

            foreach (Transform entrance in intersection.GetComponent<IntersectionManager>().entrances)
            {
                entrance.GetComponent<IntersectionConnectionPoint>().DetectConnections();
            }

            foreach (Transform exit in intersection.GetComponent<IntersectionManager>().exits)
            {
                exit.GetComponent<IntersectionConnectionPoint>().DetectConnections();
            }
        }
    }

    public void InitializeStreets()
    {
        foreach (Transform street in streets)
        {
            street.GetComponent<StreetManagement>().CalculateStreetLenght();
            street.GetComponent<StreetManagement>().DetectConnections();
        }
    }

    public void InitializeStreetLanes()
    {
        foreach (Transform streetLane in streetLanes)
        {
            if (streetLane.parent.GetComponent<StreetManagement>().isCurve == false)
            {
                streetLane.GetComponent<StreetLaneManagement>().DetectConnectionPoints();
            }
            else
            {
                streetLane.GetComponent<StreetLaneManagement>().DetectConnectionPointsCurve();
            }
        }
    }
    #endregion

    public void InitializeVehicles()
    {
        foreach (Transform vehicle in vehicleParent)
        {
            vehicle.gameObject.SetActive(true);
            vehicle.GetComponent<VehicleManager>().InitializeVehicleManagerIteration1();
            vehicle.GetComponent<VehicleMover>().InitializeVehicleMover();
            vehicle.GetComponent<ParabolaController>().InitializeParabolaController();
            vehicle.GetComponent<DStarAlgorithm2>().InitializeAlgorithm();
            vehicle.GetComponent<VehicleSpeedManager>().InitializeVehicleSpeedManager();
            vehicle.GetComponent<VehicleManager>().InitializeVehicleManagerIteration2();
        }
    }
}
