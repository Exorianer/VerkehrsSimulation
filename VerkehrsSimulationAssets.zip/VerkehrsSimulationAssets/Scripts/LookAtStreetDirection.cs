﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookAtStreetDirection : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The LookAtStreetDirection script is responsible for turning the vehicle according to the direction they are driving to
    //It is located on the vehicle

    #endregion

    public void LookAtTheStreet(Vector3 positionToLookAt)
    {
        Vector3 newLookPosition = positionToLookAt - transform.position;
        Quaternion rotation = Quaternion.LookRotation(newLookPosition);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, Time.deltaTime * GetComponent<ParabolaController>().currentSpeed);
    }
}
