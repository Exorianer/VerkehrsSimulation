﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
public class TextureTilingController : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The TextureTilingController script exists to scale textures longer without stretching it
    //It is located on each street lane

    #endregion

    #region Variables

    Renderer rend;

    #endregion

    void Start()
    {
        rend = GetComponent<Renderer>();
        rend.sharedMaterial.SetTextureScale("_MainTex", new Vector2(transform.parent.localScale.z, transform.parent.localScale.x));
    }
}