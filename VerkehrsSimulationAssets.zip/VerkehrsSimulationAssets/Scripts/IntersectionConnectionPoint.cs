﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IntersectionConnectionPoint : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The IntersectionConnectionPoint script is needed to get a connection from the vehicle (over the street lane) to the intersection
    //It detects which street lane and intersection it is colliding with and saves them
    //It is located in the intersections on each entrance / exit point

    #endregion

    #region Variables

    public Transform connectedIntersection;
    public Transform connectedStreetLane;

    #endregion

    public void DetectConnections()
    {
        Collider[] collisionCollider = Physics.OverlapSphere(position: transform.position, radius: 0.5f);

        foreach (Collider collision in collisionCollider)
        {
            if (collision.transform.tag == "Intersection")
                connectedIntersection = collision.transform;

            if (collision.transform.tag == "StreetLane")
                connectedStreetLane = collision.transform;
        }
    }
}
