﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "costSave", menuName = "dStarSave")]
public class dStarSave : ScriptableObject
{
    #region Author

    //This script was created by Bastian Steffensen

    #endregion

    #region Description

    //A dStarSave ScriptableObject exists to store information about every intersection

    #endregion

    #region Variables

    public int gCost;
    public int hCost;
    public int fCost;
    public int busyness;
    public int rank;
    public Transform intersection;
    public Transform lastSearchedPosition;
    public List<Transform> tempNeighbor = new List<Transform>();

    public List<Transform> neighbors = new List<Transform>();
    public List<Transform> connectingStreets = new List<Transform>();

    #endregion
}
