﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VehicleManager : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The VehicleManager script is essential for the vehicle
    //It is the central communication point of the vehicle
    //It checks on which part of the infrastructure it is and communicates with the other components of the vehicle
    //It is located on the vehicle

    #endregion

    #region Variables

    public StreetLaneManagement streetLaneManagement;
    public IntersectionVehicleInformation intersectionVehicleInformation;
    private VehicleMover vehicleMover;
    private ParabolaController parabolaController;

    public Transform currentStreet;
    public Transform targetStreet;
    public Transform currentIntersection;
    public Transform nextIntersection;

    private bool vehicleIsOnTargetStreet;

    #endregion

    public void InitializeVehicleManagerIteration1()
    {
        vehicleMover = GetComponent<VehicleMover>();
        parabolaController = GetComponent<ParabolaController>();

        intersectionVehicleInformation = ScriptableObject.CreateInstance("IntersectionVehicleInformation") as IntersectionVehicleInformation;
        intersectionVehicleInformation.vehicleLength = GetComponent<BoxCollider>().size.z;

        CheckForFirstStreet();

    }

    public void InitializeVehicleManagerIteration2()
    {
        NotifyTrafficManagerEnterStreet();
    }

    public void CheckForFirstStreet()
    {
        Collider[] collisionCollider = Physics.OverlapSphere(position: transform.position, radius: 1f);

        foreach (Collider collision in collisionCollider)
        {
            if (collision.transform.tag == "StreetLane")
            {
                AssignCurrentStreet(newCurrentStreet: collision.transform);

                nextIntersection = streetLaneManagement.entrance.GetComponent<IntersectionConnectionPoint>().connectedIntersection;
            }
        }
    }

    #region CollisionDetection
    void OnCollisionEnter(Collision collision)
    {
        if (collision.transform.tag == "StreetLane")
        {
            if (collision.transform != currentStreet)
            {
                VehicleIsOnNewStreet(newStreet: collision.transform);
            }
        }
        else if (collision.transform.tag == "Intersection")
        {
            VehicleIsOnNewIntersection(newIntersection: collision.transform);
        }
    }
    #endregion

    public void VehicleIsOnNewStreet(Transform newStreet)
    {
        vehicleMover.TurnDone();

        AssignCurrentStreet(newCurrentStreet: newStreet);
        AssignNextIntersection();
        GetInformationFromNextIntersection();
        StartDriveToEntrance();
        NotifyTrafficManagerEnterStreet();
    }

    public void VehicleIsOnNewIntersection(Transform newIntersection)
    {
        AssignIntersection(newCurrentIntersection: newIntersection);
        NotifyTrafficManagerLeaveStreet();
    }

    public void AssignCurrentStreet(Transform newCurrentStreet)
    {
        parabolaController.isOnIntersection = false;
        parabolaController.ResetAnimationTime();
        parabolaController.distanceTravelledOnStreet = 0;

        currentStreet = newCurrentStreet.transform;

        if (currentStreet == targetStreet)
            vehicleIsOnTargetStreet = true;

        streetLaneManagement = currentStreet.GetComponent<StreetLaneManagement>();
        streetLaneManagement.AdVehicle(newVehicle: transform);
    }

    public void AssignNextIntersection()
    {
        nextIntersection = streetLaneManagement.entrance.GetComponent<IntersectionConnectionPoint>().connectedIntersection;
    }

    public void GetInformationFromNextIntersection()
    {
        if (vehicleMover.turnsDone < vehicleMover.directions.Count)
        {
            nextIntersection.GetComponent<IntersectionManager>().SetVehicleEntranceAndExit(Vehicle: transform);
        }
    }

    public void StartDriveToEntrance()
    {
        if (GetComponent<VehicleMover>().pathSuccessfullyCreated)
        {
            nextIntersection.GetComponent<IntersectionManager>().DriveToEntrance(transform);
        }
    }

    public void NotifyTrafficManagerEnterStreet()
    {
        TrafficManager trafficManager = nextIntersection.GetComponent<TrafficManager>();

        int queueNumber = trafficManager.GetQueueNumberOfVehicle(street: currentStreet, vehicleQueueNumber: int.MaxValue);

        parabolaController.trafficManager = trafficManager;
        parabolaController.queueNumber = queueNumber;

        trafficManager.GetQueueOrder(null, vehicleQueueNumber: queueNumber);
    }

    public void NotifyTrafficManagerLeaveStreet()
    {
        TrafficManager trafficManager = nextIntersection.GetComponent<TrafficManager>();

        trafficManager.GetQueueOrder(null, vehicleQueueNumber: parabolaController.queueNumber);
    }

    public void AssignIntersection(Transform newCurrentIntersection)
    {
        parabolaController.isOnIntersection = true;
        parabolaController.ResetAnimationTime();
        parabolaController.distanceTravelledOnStreet = 0;

        currentIntersection = newCurrentIntersection;
        currentIntersection.GetComponent<IntersectionManager>().DriveTroughIntersection(transform);

        currentStreet.GetComponent<StreetLaneManagement>().RemoveVehicle(oldVehicle: transform);
    }
}
