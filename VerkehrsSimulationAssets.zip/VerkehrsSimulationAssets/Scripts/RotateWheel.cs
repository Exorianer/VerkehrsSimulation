﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateWheel : MonoBehaviour
{
    #region Author

    //This script was created by Niklas Dette

    #endregion

    #region Description

    //The RotateWheel script rotates the wheels
    //It is located on the wheel object in the vehicle

    #endregion

    #region Variables

    ParabolaController parabolaController;

    #endregion

    void Start()
    {
        parabolaController = transform.parent.parent.GetComponent<ParabolaController>();
    }

    void Update()
    {
        transform.Rotate(Vector3.right * (parabolaController.currentSpeed * 100 * Time.deltaTime));
    }
}
